/**
 * 
 */
package org.kb.indexer;

import java.io.IOException;
import java.util.List;

import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.UpdateResponse;
import org.apache.solr.common.SolrInputDocument;
import org.kb.document.XMLTags;

/**
 * @author avinav
 *
 */
public class NewsIndexer {
	private String urlString;
	private SolrServer solr;
	private Long id = 1L;
	
	public NewsIndexer(String urlString, Long id) {
		this.urlString = urlString;
		try {
			this.solr = new HttpSolrServer(this.urlString);
			this.id = id;
		} 
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Index documents present in path corpusPath
	 * @param corpusPath
	 */
	public void index(List<XMLTags> tagList) {
		SolrInputDocument document = new SolrInputDocument();
		boolean isField = false;
//		document.addField("id", this.id.toString());
		for (XMLTags tag : tagList) {
			document.addField(tag.getTagName(), tag.getText().toString());
			if("FILEID".equals(tag.getTagName())) {
				isField = true;
			}
		}
		if (!isField) {
			document.addField("FILEID", "URL");
		}
		try {
			UpdateResponse response = solr.add(document);
		} catch (SolrServerException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void commit() {
		try {
			solr.commit();
		} catch (SolrServerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
