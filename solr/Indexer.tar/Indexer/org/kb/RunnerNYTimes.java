/**
 * 
 */
package org.kb;

import java.io.File;
import java.util.List;

import org.kb.document.ParserException;
import org.kb.document.XMLTags;
import org.kb.parser.NYTimesParser;
import org.kb.indexer.NewsIndexer;

/**
 * @author avinav
 *
 */
public class RunnerNYTimes {

	/**
	 * @param args
	 */
	public static void NYTimes(String ipDir, String xmlDir, String solrURL) {
		// TODO Auto-generated method stub
		NYTimesParser nParser = new NYTimesParser();
		Long id = 1L;
		NewsIndexer nx = new NewsIndexer(solrURL, id);
		try {

			//more? idk!
			if (!xmlDir.endsWith(File.separator)) {
				xmlDir = xmlDir + File.separator;
			}
			File ipDirectory = new File(ipDir);
			String[] catDirectories = ipDirectory.list();
			String[] files;
			File dir, xmlOut, xmlIn;
			String outDir;

			for (String cat : catDirectories) {
				File ipDirectory1 = new File(ipDir + File.separator + cat);
				String[] catDirectories1 = ipDirectory1.list();
				for (String cat1 : catDirectories1) {
					dir = new File(ipDir+ File.separator+ cat + File.separator + cat1);
					files = dir.list();
					outDir = xmlDir + cat + File.separator + cat1;
					if (files == null)
						continue;
					for (String f : files) {
						try {
							//d = ReutersParser.parse(dir.getAbsolutePath() + File.separator +f);
							xmlIn = new File(ipDir + File.separator + cat + File.separator +
									cat1 + File.separator + f);
							xmlOut = new File(outDir + File.separator + f);
							if (f.endsWith(".xml")) {
								List<XMLTags> tagList = nParser.parseNYCorpus(xmlIn);
//								ToXml.writeXML(xmlOut, ToXml.createDocument(tagList));
								nx.index(tagList);
							}
						} catch (ParserException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} 			
					}
				}
			}
			nx.commit();
//			PrintStream ps = new PrintStream(new FileOutputStream(xmlDir + "id.txt"));
//			ps.println(ToXml.getId());
//			ps.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}
