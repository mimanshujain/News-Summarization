/**
 * 
 */
package org.kb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.kb.document.XMLTags;
import org.kb.indexer.NewsIndexer;

/**
 * @author avinav
 *
 */
public class IndexRunner {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document doc = null;
		String path_url = args[2];
		String solrURL = args[1];
		Long id = 0L;
		if (!path_url.endsWith(File.separator)) {
			path_url = path_url + File.separator; 
		}
		if (args[0].equals("u")) {
			doc = Jsoup.connect(path_url).get();
			index(doc,id,solrURL);
		}
		else if(args[0].equals("f")){
			doc = Jsoup.parse(new File(path_url), "UTF-8");
			index(doc,id,solrURL);
		}
		else if(args[0].equals("d")){
			File dir = new File(path_url);
			String[] files = dir.list();
			for (int i = 0; i < files.length; i++) {
				if (files[i].endsWith(".html")) {
					doc = Jsoup.parse(new File(path_url + files[i]), "UTF-8");
					index(doc,id,solrURL);
					id ++;
				}
			}
		}
		else {
			if (path_url.endsWith(File.separator)) {
				path_url = path_url.substring(0,path_url.length() - 1);
			}
			System.out.println("File: " + path_url);
			FileReader fr = new FileReader(path_url);
			BufferedReader br = new BufferedReader(fr);
			String url = null;
			while ((url = br.readLine()) != null) {
				if (!url.isEmpty()) {
					System.out.println("URL: " + url);
					doc = Jsoup.connect(url).get();
					System.out.println("SOLR URL: " + solrURL);
					index(doc,id,solrURL);
					id ++;
					try {
						TimeUnit.SECONDS.sleep(5);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("indexed " + url);
				}
			}
			br.close();
		}
	}
	public static void index(Document doc, Long id, String solrURL) {

		List<XMLTags> tagList = new ArrayList<XMLTags>();
		
		Elements elements = doc.getElementsByTag("meta");
		for (Element e : elements) {
			if ("og:url".equals(e.attr("property"))) {
				tagList.add(new XMLTags("url",new StringBuffer(e.attr("content")), null));
			}
			if ("author".equals(e.attr("name"))) {
				tagList.add(new XMLTags("AUTHOR",new StringBuffer(e.attr("content")),null));
			}
			else if ("news_keywords".equals(e.attr("name"))) {
				tagList.add(new XMLTags("TAGS",new StringBuffer(e.attr("content")), null));
			}
			else if ("article:modified_time".equals(e.attr("property"))) {
				String date = e.attr("content");
				date = date.substring(0, 19);
				date = date + "Z";
				tagList.add(new XMLTags("NEWSDATE", new StringBuffer(date), null));
			}
		}
		elements = doc.getElementsByTag("h1");
		for (Element e : elements) {
			if ("headline".equals(e.attr("itemprop"))) {
				tagList.add(new XMLTags("TITLE", new StringBuffer(e.text()), null));
			}
		}
		elements = doc.getElementsByTag("div");
		for (Element e : elements) {
			if ("articleBody".equals(e.attr("itemprop"))) {
				tagList.add(new XMLTags("CONTENT", new StringBuffer(e.text()), null));
			}
		}
		
		NewsIndexer nx = new NewsIndexer(solrURL,id);
		nx.index(tagList);
		nx.commit();

	}

}
